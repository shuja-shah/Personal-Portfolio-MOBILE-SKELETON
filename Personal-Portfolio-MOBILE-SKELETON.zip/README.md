![](https://img.shields.io/badge/Microverse-blueviolet)

# PERSONAL PORTFOLIO

> In this project.  I have created a personal portfolio website, using MOBILE-FIRST APPROCH. 
> I have used a Template from Figma (provided by microverse).
>This project will feature the skeleton only.


## Built With

- HTML5
- CSS3

👤 **Author**

- GitHub: [@githubhandle](https://github.com/shuja-shah)
- Twitter: [@twitterhandle](https://twitter.com/SyedShujaHussa3)
- LinkedIn: [LinkedIn](https://www.linkedin.com/in/shahshujahussa/)



## 🤝 Contributing

Contributions, issues, and feature requests are welcome!


## Show your support

Give a ⭐️ if you like this project!


## 📝 License

This project is [MIT](./MIT.md) licensed.
